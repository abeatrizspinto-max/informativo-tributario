/* Service worker do Informativo Tributário Diário.
   Estratégia: network-first para dados.js e index.html (para pegar a atualização das 07h),
   cache-first para o resto. Funciona offline depois da primeira visita. */

const CACHE = "informativo-tributario-v1";
const ESSENCIAIS = [
  "./",
  "./index.html",
  "./dados.js",
  "./manifest.webmanifest",
  "./icone-192.png",
  "./icone-512.png"
];

self.addEventListener("install", (ev) => {
  ev.waitUntil(
    caches.open(CACHE).then((c) => c.addAll(ESSENCIAIS)).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (ev) => {
  ev.waitUntil(
    caches.keys()
      .then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (ev) => {
  const req = ev.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);
  const sempreFresco = url.pathname.endsWith("dados.js") ||
                       url.pathname.endsWith("index.html") ||
                       url.pathname.endsWith("/");

  if (sempreFresco) {
    ev.respondWith(
      fetch(req)
        .then((res) => {
          const copia = res.clone();
          caches.open(CACHE).then((c) => c.put(req, copia));
          return res;
        })
        .catch(() => caches.match(req).then((r) => r || caches.match("./index.html")))
    );
    return;
  }

  ev.respondWith(
    caches.match(req).then((r) => r || fetch(req).then((res) => {
      const copia = res.clone();
      caches.open(CACHE).then((c) => c.put(req, copia));
      return res;
    }))
  );
});
