# Informativo Tributário Diário

App de leitura diária das decisões relevantes do **STF, STJ, TRFs e CARF** em matéria tributária.
Atualizado automaticamente todo dia às **07h (horário de Brasília)**.

**Senha inicial de acesso: `aguila2026`** — trocável a qualquer momento em `trocar-senha.html`.

## Arquivos (todos vão na raiz do repositório)

| Arquivo | Função |
|---|---|
| `index.html` | O app. Interface, busca, filtros, trava de senha. |
| `dados.js` | A base de decisões. **É o único arquivo que a rotina diária edita.** |
| `sw.js` | Service worker — faz o app funcionar offline. |
| `manifest.webmanifest` | Permite instalar o app na tela inicial do celular. |
| `robots.txt` | Pede aos buscadores que não indexem o app. |
| `trocar-senha.html` | Gera os hashes da senha nova, para colar no `index.html`. |
| `icone-180.png`, `icone-192.png`, `icone-512.png` | Ícones do app. |

## Publicar pelo celular (GitHub Pages)

1. No navegador do celular, abrir **github.com** e criar conta gratuita.
2. Menu → **New repository** → nome `informativo-tributario` → marcar **Public** → *Create repository*.
3. Na tela do repositório vazio, tocar em **uploading an existing file**.
4. Descompactar o zip no celular e enviar os **9 arquivos soltos** (não a pasta). No iPhone, o zip
   descompacta sozinho no app Arquivos ao ser tocado; no Android, use o gerenciador de arquivos.
   Dá para enviar em duas ou três levas — a cada leva, tocar em *Commit changes*.
5. **Settings** → **Pages** → Source: *Deploy from a branch* → branch `main`, pasta `/ (root)` → *Save*.
6. Em 2 a 3 minutos o endereço aparece na mesma tela:
   `https://SEU-USUARIO.github.io/informativo-tributario/`

## Instalar como aplicativo

- **iPhone — precisa ser no Safari:** abrir o endereço → botão Compartilhar → *Adicionar à Tela de Início*.
- **Android — Chrome:** abrir o endereço → menu ⋮ → *Instalar app* (ou *Adicionar à tela inicial*).

Depois disso o app abre em tela cheia, sem barra de navegador, funciona offline e busca a
versão nova a cada abertura.

## Sobre a trava de senha

O app pede senha antes de mostrar qualquer conteúdo, e lembra do acesso por 30 dias no aparelho.
**Isso não é criptografia.** Como o repositório é público, quem souber procurar consegue ler o
`dados.js` direto. A trava serve para manter o conteúdo fora da vitrine e dos buscadores.
Para proteção real, o caminho é GitHub Pro (US$ 4/mês) com repositório privado.

Para trocar a senha: abrir `trocar-senha.html`, digitar a senha nova e seguir as três linhas de
instrução que aparecem na tela.

## Como a atualização diária funciona

Todo dia às 07h uma tarefa agendada varre STF, STJ, TRFs e CARF, seleciona as decisões
relevantes, redige a análise no padrão da skill `registrar-decisao-tributaria` e **acrescenta os
novos registros no topo do array `DECISOES` em `dados.js`**, sem remover nada do que já existe.
A constante `ATUALIZADO_EM` é atualizada junto. O informativo do dia também chega por e-mail.

## Regras de rigor da base

- Nunca inventar número de tema, data, relator, dispositivo ou resultado — campo incerto fica `"—"`.
- Distinguir o que veio do inteiro teor do que veio de notícia, pelo campo `origem`.
- Nunca sobrescrever registros anteriores.
- Decisão ainda pendente vai para o array `RADAR`, nunca para `DECISOES`, e sem antecipar resultado.
